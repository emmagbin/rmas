<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  
  
  

  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
  <h2><center>MOTOR PROPOSAL FORM <br>
  PRIVATE INDIVIDUAL</center></h2>

  <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">1. PROPOSERS PERSONAL DETAILS</a>
        </h4>
      </div>
	  
	  
      <div id="collapse1" class="panel-collapse collapse in">
        <div class="panel-body">
        <form class="form-horizontal" action="/action_page.php">
			<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">1. Full Name of Proposer</label>
				<div class="col-sm-8"> 
				  
				</div>
			</div>
    
			  <div class="form-group">
				<label class="control-label col-sm-2" for="email">Surname:</label>
				<div class="col-sm-10">
				  <input type="email" class="form-control" id="email" placeholder="Enter Surname">
				</div>
			  </div>
			  
			  <div class="form-group">
				<label class="control-label col-sm-2" for="pwd">Other Names:</label>
				<div class="col-sm-10"> 
				  <input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				</div>
			  </div>
			  <div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">2. Do you have a policy with us</label>
				<div class="col-sm-8"> 
				<label class="checkbox-inline">
      <input type="checkbox" name="optradio">Yes
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" name="optradio">No
    </label>
	
	
				
				 
				</div>
				</div>
    
				<div class="form-group"> 
			  <label class="control-label col-sm-2" style="text-align:left">3. Postal Address</label>
				<div class="col-sm-10"> 
				<textarea class="form-control" rows="2" id="comment"></textarea>
				  
				</div>
				</div>
				<div class="row">
				
				<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">4. Age</label>
				<div class="col-sm-8"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
				
					<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">Profession/Occupation</label>
				<div class="col-sm-8"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
					
				
				</div>
				
				
				
				
				<div class="row">
				
				<div class="col-sm-4">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-6" style="text-align:left">5. Tel No.</label>
				<div class="col-sm-6"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
				
					<div class="col-sm-4">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-6" style="text-align:left">Fax No.</label>
				<div class="col-sm-6"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				<div class="col-sm-4">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-6" style="text-align:left">Email Address </label>
				<div class="col-sm-6"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
				
					
				
				</div>
				
				
					<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">4. Insurance Required</label>
				<div class="col-sm-8"> 
				  
				</div>
			</div>
					<div class="row">
				<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">From</label>
				<div class="col-sm-8"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
				
					<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">To</label>
				<div class="col-sm-8"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
					
				
				</div>

 
		</form>
        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">2.DETAILS OF VEHICAL TO BE INSURED</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
		  <form class="form-horizontal" action="/action_page.php">		
				<div class="row">
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-2" style="text-align:left">Registration Number:</label>
								<div class="col-sm-10"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				
						
				</div>
			  
			  <div class="row">
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">Make of Vehicle</label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">Type of body</label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				</div>
				
				<div class="row">
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-2" style="text-align:left">Seating Capacity (including driver)</label>
								<div class="col-sm-10"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				
						
				</div>

				
				<div class="row">
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">Engine Capacity (CC/HP) </label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">Year of Manufacture</label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				</div>
				
				<div class="row">
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">Engine Number</label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">Chasis Number</label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				</div>
				
				<div class="form-group"> 
					<label class="control-label col-sm-4" style="text-align:left">Proposers Estimate of</label>
					<div class="col-sm-8"> 
					  
					</div>
				</div>
				<div class="row">
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">(a) Present value of Car (Including accessories) </label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				
						
				
				
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-4" style="text-align:left">(b) value of accessories only</label>
								<div class="col-sm-8"> 
									<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
								</div>
							</div>
						</div>
				
					</div>	
				
				
				<div class="row">
						<div class="col-sm-12">
							 <div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">Insurance Required</label>
				<div class="col-sm-8"> 
				
	
	
	<label class="checkbox-inline">
      <input type="checkbox" name="optradio">Comprehensive
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" name="optradio">Third Party & theft
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" name="optradio">Third Party Only
    </label>
	
				</div>
				</div>
						</div>
				</div>	
				
				
				
    
		
				
				
				
				
                                        
                                            
                                        
				
				
				
			
		</form>
				
			
				
		</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">3. VEHICLE DETAILS CONTINUE</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">
							<table class="table table-bordered">
						<tbody>
						  <tr>
							<td >  <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(i) State address where motor vehicle is usually garaged:</label>	
												</div>
											</div>
									
											
									</div>
									<br>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(ii) Is the vehicle normally parked within your premises overnight?</label>	
												</div>
											</div>	
									</div>
									
							
							</td>
							<td> 
							 <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(i)">
												</div>
											</div>
									
											
									</div>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(ii)">
												</div>
											</div>
									
											
									</div>
							
							
							
						  
						   
						  </tr>
						  
								<tr>
							<td >  <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(i) State address where motor vehicle is usually garaged:</label>	
												</div>
											</div>
									
											
									</div>
									<br>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(ii) Is the vehicle normally parked within your premises overnight?</label>	
												</div>
											</div>	
									</div>
									
							
							</td>
							<td> 
							 <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(i)">
												</div>
											</div>
									
											
									</div>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(ii)">
												</div>
											</div>
									
											
									</div>
							
							
							
						  
						   
						  </tr>
						  <tr>
							<td >  <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(i) State address where motor vehicle is usually garaged:</label>	
												</div>
											</div>
									
											
									</div>
									<br>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(ii) Is the vehicle normally parked within your premises overnight?</label>	
												</div>
											</div>	
									</div>
									
							
							</td>
							<td> 
							 <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(i)">
												</div>
											</div>
									
											
									</div>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(ii)">
												</div>
											</div>
									
											
									</div>
							
							
							
						  
						   
						  </tr>
						  
						  <tr>
							<td >
						

							<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(4) (a) Has any Insurance cover</label>	
												</div>
											</div>
									
											
									</div>
									
							<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(b) Declined your proposal?</label>	
												</div>
											</div>
									
											
									</div>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left"> Required you to bear the first portion of any loss or imported any specail condition?</label>	
												</div>
											</div>
									
											
									</div>
									
									
									
									
							
							</td>
							<td> 
							 <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(i)">
												</div>
											</div>
										</div>
											 <div class="row">
											<div class="col-sm-2">
												<label class="checkbox-inline">
												 (b) Years
												</label>
												
											</div>
											<div class="col-sm-10">
																							
												<input type="number" class="form-control"  placeholder="(years)">
											</div>
									
											
									</div>
									<br>
									 <div class="row">
											<div class="col-sm-2">
												<label class="checkbox-inline">
												 Compare
												</label>
												
											</div>
											<div class="col-sm-10">
																							
												<input type="number" class="form-control"  placeholder="(years)">
											</div>
									
											
									</div>
									
	
									
									
							
							
							
						  
						   
						  </tr>
						  <tr>
							<td >
						

							<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(5. Has any Insurance cover</label>	
												</div>
											</div>
									
											
									</div>
									
							<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(i) Declined your proposal?</label>	
												</div>
											</div>
									
											
									</div>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(ii) Required you to bear the first portion of any loss or imported any specail condition?</label>	
												</div>
											</div>
									
											
									</div>
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(iii) Required an increased premium?</label>	
												</div>
											</div>
									
											
									</div>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">(iv) Refused to remove or cancel your policy?</label>	
												</div>
											</div>	
									</div>
									
							
							</td>
							<td> 
							 <div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(i)">
												</div>
											</div>
									<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(ii)">
												</div>
											</div>
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(iii)">
												</div>
											</div>
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(iv)">
												</div>
											</div>
											
									</div>
									
									
							
							
							
						  
						   
						  </tr>
						  <tr>
							<td >  
							<div class="form-group"> 
											  <label class="control-label col-sm-4" style="text-align:left">6. Extra Benefits</label>
												<div class="col-sm-8"> 
												  
												</div>
											</div>
											<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">Do you wish to increase the Third Party Property?</label>	
												</div>
											</div>
									
											
									</div>
									<br>
												
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">Damage Limit granted under the standard Cover</label>	
												</div>
											</div>	
									</div>
									
							
							</td>
							<td> 
							
	
							 <div class="row">
											<div class="col-sm-4">
												<label class="checkbox-inline">
      <input type="checkbox" name="optradio">Yes
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" name="optradio">No
    </label>
											</div>
											<div class="col-sm-8">
												
    <input type="text" class="form-control"  placeholder="(ii)">
											</div>
									
											
									</div>
									<br>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<label class="control-label col-sm-12" style="text-align:left">if yes to what limit?</label>
												</div>
											</div>
									
											
									</div>
									<br>
									
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group"> 
													<input type="text" class="form-control"  placeholder="(ii)">
												</div>
											</div>
									
											
									</div>
							
							
							
						  
						   
						  </tr>
						  
						  
						  
						  
						  
						</tbody>
					  </table>
		</div>
      </div>
    </div>
	<br>
	
	
				<div class="row">
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-12" style="text-align:justify">
								I/We the undersigned do hereby warrant the truth and correctness of all above statement and
								particulars and i/we declare that i/we  have not withheld any material information. i/We undertake 
								that the vehicle or vehicles to be insured shall not be driven by any person who to my/our knowledge has been 
								refused any Motor Vehicle insurance or continuance thereof. And i/we agreed that the above propose and this Warrant
								and Declaration shall be the basis of the contract between me/us and the METROPOLITANT INsURANCE COMPaNY LIMITED 
								and i/we agree to abide by the terms and conditions of the policy issued in answer to this proposal.
								</label>	
							</div>
						</div>	
				</div>
				<br>
				<div class="row">
				
				<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">Signatur of Proposer</label>
				<div class="col-sm-8"> 
				<input type="text" class="form-control" id="pwd" placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
				
					<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">Date</label>
				<div class="col-sm-8"> 
				<input type="date" class="form-control"  placeholder="Enter other names">
				  
				</div>
				</div>
				
				</div>
				
					
				
				</div>
				
				<br>
	
	
				<div class="row">
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-12" style="text-align:justify">
								 No Liability is accepted by accepted by the Company until the issues of the policy and the premium,
								or the issues of a duly authorised Cover Noted by the Company
								</label>	
							</div>
						</div>	
				</div>
				
				<br>
	
	
				<div class="row">
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-12" style="text-align:justify">
								 IMPORTANT
								</label>	
							</div>
						</div>	
						<div class="col-sm-12">
							<div class="form-group"> 
								<label class="control-label col-sm-12" style="text-align:left">
								 If a non-standard part and or accessory is fitted and insurance is required. please indicate type
								 and value separately
								</label>	
							</div>
						</div>	
				</div>

				
				<div class="row">
				
						<div class="col-sm-12">
						
						<div class="form-group"> 
					  <label class="control-label col-sm-2" style="text-align:left">Agency</label>
						<div class="col-sm-10"> 
						<input type="text" class="form-control" id="pwd" placeholder="Enter Agency">
						  
						</div>
						</div>
						
						</div>
				</div>
				<br>
				
					<div class="row">
				
				<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">Policy Number</label>
				<div class="col-sm-8"> 
				<input type="text" class="form-control"  placeholder="Enter Policy Number">
				  
				</div>
				</div>
				
				</div>
				
				
					<div class="col-sm-6">
				
				<div class="form-group"> 
			  <label class="control-label col-sm-4" style="text-align:left">Customer Number</label>
				<div class="col-sm-8"> 
				<input type="text" class="form-control"  placeholder="Enter Customer Number">
				  
				</div>
				</div>
				
				</div>
				
					
				
				</div>
      
      
      		<div class="row">
				
				
				
				
				<div class="col-sm-12">
				
				<div class="form-group"> 
			  <br><br><br>
				<div class="col-sm-12"> 
				<a href="pay"> <button  type="button" class="btn btn-default">Payment</button></a>
				  
				</div>
				</div>
				
				</div>
				
					
				
				</div>
      
      
      
  </div> 
</div>
    
<script>
$(document).ready(function(){
    $('input:checkbox').click(function() {
        $('input:checkbox').not(this).prop('checked', false);
    });
});


</script>
</body>
</html>
