<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body  >
<nav class="navbar navbar-inverse" >
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    
    
    </div>
  </div>
</nav>
<div class="container">



<div class="col-md-8" style="margin-left:-100px!important; padding-right:10px!important"> 

      <img class="img-responsive" src="img/insurance.png" width="100%"  alt="Chania">  
      <br>
      
</div>

<div class="col-sm-4" >

  <h2><center>Welcome to MEC Online Payment Platform</center></h2>
  
  <form action="/action_page.php">
    <div class="form-group">
      <label for="email">Insurance Type</label>
      <select class="form-control" id="sel1">
        <option disabled selected >--Insurance Type-</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
      </select>
    </div>
    <div class="form-group">
      <label for="pwd">Name of Insurance Company</label>
      <select class="form-control" id="sel1">
         <option disabled selected >--Name of Insurance Companye-</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
      </select>
    </div>
   
    <a href="individaul"> <button  type="button" class="btn btn-default">Go</button></a>
  </form>
  
  
 
  </div>
</div>





</body>
</html>
